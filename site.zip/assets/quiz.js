/* WhyItSmells — "Would your nose save you?" safety test.
   Mounts into any .wq[data-quiz]. Compact mode fits a 250px ad box. */
(function () {
  var Q = [{"q":"Strong rotten-egg smell in the house. Nobody's cooking. What's the safest move?","o":["Open windows and hunt for the source","Leave right away — no switches, no flames — and call the gas company from outside","Light a candle to cover the smell"],"a":1,"x":"Natural gas is odorless; utilities add mercaptan so a leak smells like rotten eggs — or skunk. Don't stay to investigate, and don't make a spark.","g":"/house-smells-like-rotten-eggs/","gt":"Rotten-egg smell in the house"},{"q":"A fishy or urine-like smell near an outlet or light switch. No fish, no pets. Most likely?","o":["Overheating wiring or a melting outlet","The neighbors are cooking","A dead mouse in the wall"],"a":0,"x":"Hot electrical insulation gives off a sharp fishy, urine-like chemical smell. It's a fire risk: shut off that breaker and get it checked.","g":"/house-smells-like-fish/","gt":"Fishy smell with no fish"},{"q":"Which dangerous gas can your nose NOT detect at all?","o":["Natural gas","Sewer gas","Carbon monoxide"],"a":2,"x":"Carbon monoxide has no color, taste or smell. Gas and sewer gas both stink; CO is the one no nose catches. Only a working CO detector does.","g":"/car-exhaust-smell-inside/","gt":"Exhaust smell inside the car"},{"q":"First cold night of the year. The furnace kicks on and the house smells like burning dust for 20 minutes, then it fades.","o":["Normal — dust burning off the heat exchanger","Gas leak — get out","Electrical fire — call 911"],"a":0,"x":"A brief burning-dust smell at seasonal startup is normal. Burning plastic, smoke, or a smell that doesn't fade is not — shut the furnace off.","g":"/furnace-smells-like-burning/","gt":"Furnace smells like burning"},{"q":"Sewage smell in a guest bathroom nobody has used in weeks. Usual cause?","o":["A dried-out drain trap letting sewer gas up","A broken sewer main under the house","Mold behind the wall"],"a":0,"x":"The water seal in an unused drain evaporates and sewer gas comes up the pipe. Run every drain for 30 seconds. If it comes back, that's a plumber.","g":"/bathroom-smells-like-sewage/","gt":"Bathroom smells like sewage"},{"q":"Hot water smells like rotten eggs. Cold water is fine. Dangerous?","o":["Yes — gas is leaking into the water heater","Usually not — bacteria reacting with the heater's anode rod","Yes — sewage is in the water line"],"a":1,"x":"Only-hot-water smell points at the water heater, where bacteria react with the magnesium anode rod to make hydrogen sulfide. Gross, not dangerous; a different anode rod fixes it.","g":"/hot-water-smells-bad/","gt":"Hot water smells bad"},{"q":"Musty smell every time the AC kicks on.","o":["Refrigerant leak — emergency","Mold on the evaporator coil or in the drain — fix it soon","Normal for air conditioning — ignore it"],"a":1,"x":"Refrigerant is nearly odorless. Musty-on-startup is mold on the wet evaporator coil or in a clogged drain, blown through every vent. Not an emergency — not something to live with either.","g":"/ac-smells-musty/","gt":"AC smells musty"},{"q":"Sweet, syrupy smell inside the car with the heat on, and the windshield keeps fogging.","o":["Coolant leaking from the heater core","Someone spilled a soda","Exhaust leak"],"a":0,"x":"Antifreeze smells sweet; a leaking heater core mists it into the cabin and fogs the glass. Fix it before the engine runs low on coolant. An exhaust leak smells acrid — and that one is an emergency.","g":"/car-smells-like-antifreeze/","gt":"Car smells like antifreeze"}];
  var TIERS = [
    [8, "Your nose would save you.", "You read smells like a pro. Keep a CO detector anyway — that's the one no nose catches."],
    [6, "Mostly — but not every time.", "A couple of these would have fooled you. Read those guides; they're short."],
    [4, "Coin flip.", "Your nose needs a refresher. Start with the ones you missed."],
    [0, "Your nose would not save you.", "The good news: that's exactly what these guides are for."]
  ];
  var PAGE = "https://whyitsmells.com/smell-safety-test/";

  function h(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;"); }

  function mount(root) {
    var compact = root.classList.contains("wq-compact");
    var i = 0, score = 0, missed = [], started = false;
    var start = root.querySelector(".wq-start");
    if (start) start.addEventListener("click", function (e) { e.preventDefault(); begin(); });

    function begin() { started = true; i = 0; score = 0; missed = []; root.classList.add("wq-live"); question(); }

    function question() {
      var d = Q[i];
      root.innerHTML = "";
      var top = h("div", "wq-top");
      top.appendChild(h("span", "wq-eye", "Would your nose save you?"));
      top.appendChild(h("span", "wq-prog", (i + 1) + "/" + Q.length));
      root.appendChild(top);
      root.appendChild(h("p", "wq-q", esc(d.q)));
      var ol = h("div", "wq-opts");
      d.o.forEach(function (t, k) {
        var b = h("button", "wq-opt", esc(t)); b.type = "button";
        b.addEventListener("click", function () { answer(k); });
        ol.appendChild(b);
      });
      root.appendChild(ol);
    }

    function answer(k) {
      var d = Q[i], right = k === d.a;
      if (right) score++; else missed.push(i);
      root.innerHTML = "";
      var top = h("div", "wq-top");
      top.appendChild(h("span", "wq-verdict " + (right ? "ok" : "no"), right ? "✓ Right" : "✗ Not quite"));
      top.appendChild(h("span", "wq-prog", (i + 1) + "/" + Q.length));
      root.appendChild(top);
      if (!right) root.appendChild(h("p", "wq-ans", "Answer: <b>" + esc(d.o[d.a]) + "</b>"));
      root.appendChild(h("p", "wq-x", esc(d.x)));
      var row = h("div", "wq-row");
      var g = h("a", "wq-guide", esc(d.gt) + " →"); g.href = d.g; row.appendChild(g);
      var nx = h("button", "wq-next", i + 1 < Q.length ? "Next question →" : "See my score →"); nx.type = "button";
      nx.addEventListener("click", function () { i++; i < Q.length ? question() : result(); });
      row.appendChild(nx);
      root.appendChild(row);
    }

    function result() {
      root.innerHTML = "";
      var t = TIERS.filter(function (x) { return score >= x[0]; })[0];
      var top = h("div", "wq-top");
      top.appendChild(h("span", "wq-eye", "Your score"));
      root.appendChild(top);
      var sc = h("div", "wq-score");
      sc.appendChild(h("span", "wq-big", score + "<small>/" + Q.length + "</small>"));
      var tx = h("div", "wq-tier");
      tx.appendChild(h("b", null, esc(t[1])));
      tx.appendChild(h("span", null, esc(t[2])));
      sc.appendChild(tx);
      root.appendChild(sc);
      var list = h("div", "wq-missed");
      var show = missed.length ? missed : [0, 1, 2];
      list.appendChild(h("span", "wq-ml", missed.length ? "Read the ones you missed" : "Worth reading anyway"));
      show.slice(0, compact ? 3 : 8).forEach(function (n) {
        var a = h("a", null, "→ " + esc(Q[n].gt)); a.href = Q[n].g; list.appendChild(a);
      });
      root.appendChild(list);
      var row = h("div", "wq-row");
      var sh = h("button", "wq-share", "Share"); sh.type = "button";
      sh.addEventListener("click", function () {
        var text = "I scored " + score + "/" + Q.length + " on “Would your nose save you?” — the WhyItSmells safety test.";
        if (navigator.share) { navigator.share({ title: "Would your nose save you?", text: text, url: PAGE }).catch(function () {}); }
        else if (navigator.clipboard) { navigator.clipboard.writeText(text + " " + PAGE).then(function () { sh.textContent = "Link copied"; }); }
        else { location.href = PAGE; }
      });
      var rt = h("button", "wq-retake", "Retake"); rt.type = "button";
      rt.addEventListener("click", begin);
      row.appendChild(sh); row.appendChild(rt);
      if (compact) { var full = h("a", "wq-guide", "Full test →"); full.href = PAGE; row.appendChild(full); }
      root.appendChild(row);
    }
  }

  function init() {
    var nodes = document.querySelectorAll(".wq[data-quiz]");
    for (var k = 0; k < nodes.length; k++) mount(nodes[k]);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
